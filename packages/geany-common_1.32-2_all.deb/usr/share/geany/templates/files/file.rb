{fileheader}

class StdClass
	def initialize
		
	end
end

x = StdClass.new

